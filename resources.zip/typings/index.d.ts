/// <reference path="globals/google.maps/index.d.ts" />
