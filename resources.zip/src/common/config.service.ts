
export class ConfigService {
   static backendServer = 'http://api.munchado.in/api/';
   static selectedRestaurentId = 67288;
   static token = undefined;
   static munchadoAPI = 'munchadoAPI';
   static firebaseAPI = 'firebaseAPI';
}
